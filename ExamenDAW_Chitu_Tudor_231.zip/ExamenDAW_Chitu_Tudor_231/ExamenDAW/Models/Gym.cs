﻿using System.ComponentModel.DataAnnotations;

namespace ExamenDAW.Models
{
    public class Gym
    {
        [Key]
        public int Id { get; set; }

        public string? Nume { get; set; }
    }
}
