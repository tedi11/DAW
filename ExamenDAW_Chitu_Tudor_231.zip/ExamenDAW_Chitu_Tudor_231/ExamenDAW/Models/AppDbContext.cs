﻿using Microsoft.EntityFrameworkCore;

namespace ExamenDAW.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
        {
        }
        public DbSet<Membership> Memberships { get; set; }
        public DbSet<Gym> Gyms { get; set; }
        
    }
}
