﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ExamenDAW.Models
{
    public class Membership
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Titlu este obligatoriu")]
        public string Titlu { get; set; }
        [Required(ErrorMessage = "Valoare este obligatoriu")]
        [Pozitiv(ErrorMessage = "Valoare trebuie sa fie pozitiva.")]
        public int Valoare { get; set; }

        [Required(ErrorMessage = "DataEmitere este obligatoriu")]
        public DateTime DataEmitere { get; set; }
        [Required(ErrorMessage = "DataExpirare este obligatoriu")]
        [DateInFuture(ErrorMessage = "DataExpirare trebuie in viitor.")]
        public DateTime DataExpirare { get; set; }

        public int? GymId { get; set; }

        public virtual Gym? Gym { get; set; }
        [NotMapped]
        public IEnumerable<SelectListItem>? Gyms { get; set; }
        //
    }
    public class DateInFutureAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            DateTime date = (DateTime)value;
            return date > DateTime.Now;
        }
    }

    public class Pozitiv : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            int nr = (int)value;
            return nr > 0;
        }
    }
}
