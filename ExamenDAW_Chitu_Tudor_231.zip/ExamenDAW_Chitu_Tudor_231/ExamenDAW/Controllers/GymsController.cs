﻿using ExamenDAW.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ExamenDAW.Controllers
{
    public class GymsController : Controller
    {
        private readonly AppDbContext db;
        public GymsController(AppDbContext context)
        {
            db = context;
        }

        
    }
}
