﻿using ExamenDAW.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ExamenDAW.Controllers
{
    public class MembershipsController : Controller
    {
        private readonly AppDbContext db;
        public MembershipsController(AppDbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            var membership = db.Memberships.Include("Gym");

            ViewBag.Memberships = membership;
            
            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["message"];
                ViewBag.Alert = TempData["messageType"];
            }

            return View();
        }

        public IActionResult Show(int id)
        {
            Membership membership = db.Memberships.Include("Gym").Where(art => art.Id == id)
                                         .First();

            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["message"];
                ViewBag.Alert = TempData["messageType"];
            }

            return View(membership);
        }

        public IActionResult New()
        {
            Membership membership = new Membership();

            membership.Gyms = GetAllGyms();

            return View(membership);
        }

        [HttpPost]
        public IActionResult New(Membership membership)
        {
            membership.DataEmitere = DateTime.Now;

            if (ModelState.IsValid)
            {
                db.Memberships.Add(membership);
                db.SaveChanges();
                TempData["message"] = "Membershipul a fost adaugat";
                TempData["messageType"] = "alert-success";
                return RedirectToAction("Index");
            }
            else
            {
                membership.Gyms = GetAllGyms();
                return View(membership);
            }
        }

        public IActionResult Edit(int id)
        {

            Membership membership = db.Memberships.Include("Gym").Where(art => art.Id == id)
                                        .First();

            membership.Gyms = GetAllGyms();
            return View(membership);
        }

        [HttpPost]
        public IActionResult Edit(int id, Membership requestMembership)
        {
            Membership membership = db.Memberships.Include("Gym").Where(art => art.Id == id)
                                        .First();


            if (ModelState.IsValid)
            {
                membership.Titlu = requestMembership.Titlu;
                membership.Valoare = requestMembership.Valoare;
                membership.DataExpirare = requestMembership.DataExpirare;
                membership.GymId = requestMembership.GymId;
                TempData["message"] = "Membershipul a fost modificat";
                TempData["messageType"] = "alert-success";
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                requestMembership.Gyms = GetAllGyms();
                return View(requestMembership);
            }
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            Membership membership = db.Memberships
                                         .Where(art => art.Id == id)
                                         .First();

            db.Memberships.Remove(membership);
            db.SaveChanges();
            TempData["message"] = "Membershipul a fost sters";
            TempData["messageType"] = "alert-success";
            return RedirectToRoute(new { controller = "Memberships", action = "Index" });

        }

        public IActionResult CautareAbonamente()
        {
            var membership = db.Memberships.Include("Gym");
            ViewBag.Gyms = db.Gyms;
            // ViewBag.OriceDenumireSugestiva
            ViewBag.Memberships = membership;
            var search = "";
            if (Convert.ToString(HttpContext.Request.Query["search"]) != null)
            {

                search = Convert.ToString(HttpContext.Request.Query["search"]).Trim();

                ViewBag.SearchString = search;
                
                if (search != "")
                {
                    ViewBag.PaginationBaseUrl = "/Memberships/Search/?search="
                    + search;
                    ViewBag.Memberships = db.Memberships.Include("Gym").Where(at => at.Gym.Nume.Contains(search)
                );
                }
                else
                {

                    ViewBag.PaginationBaseUrl = "/Memberships/Index";
                    
                }
                
                return View();
            }
            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["message"];
                ViewBag.Alert = TempData["messageType"];
            }

            return View();
        }

        [NonAction]
        public IEnumerable<SelectListItem> GetAllGyms()
        {
            var selectList = new List<SelectListItem>();

            var gyms = from gm in db.Gyms
                       select gm;
            foreach (var gym in gyms)
            {
                selectList.Add(new SelectListItem
                {
                    Value = gym.Id.ToString(),
                    Text = gym.Nume.ToString()
                });
            }
            return selectList;
        }
    }

}
